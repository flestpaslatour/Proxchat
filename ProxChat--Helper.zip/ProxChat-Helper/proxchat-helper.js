// ProxChat Helper – pour une survie normale (monde ouvert depuis ton PC Windows).
// Minecraft se connecte à ce programme avec la commande /connect, ce programme lit les positions
// des joueurs et les envoie au site ProxChat. Aucune dépendance : Node.js suffit.
"use strict";
const http = require("http");
const crypto = require("crypto");
const fs = require("fs");
const path = require("path");

const SITE = process.env.PROXCHAT_SITE || "https://voilechatbedrock.archeo.workers.dev";
const PORT = Number(process.env.PROXCHAT_PORT || 19131);
const RANGE = 32;          // distance d'écoute en blocs
// Fréquence adaptative pour ménager le quota gratuit de Cloudflare : 2 s à plusieurs joueurs, 5 s si tu es seul, rien si personne.
const FAST_MS = 2000, SOLO_MS = 5000, IDLE_MS = 3000; // rapide seulement si des joueurs sont proches ET bougent
const KEY_FILE = path.join(__dirname, "proxchat-key.txt");
const DIMS = { 0: "minecraft:overworld", "-1": "minecraft:the_nether", 1: "minecraft:the_end" };

// ---------- Clé secrète du serveur (créée une fois, gardée dans proxchat-key.txt) ----------
function getKey() {
  try {
    const k = fs.readFileSync(KEY_FILE, "utf8").trim();
    if (/^[A-Za-z0-9_-]{32,128}$/.test(k)) return k;
  } catch (e) {}
  const k = crypto.randomBytes(30).toString("base64url");
  fs.writeFileSync(KEY_FILE, k + "\n");
  return k;
}
const KEY = getKey();
const siteName = (n) => String(n).replace(/\s+/g, "_").replace(/[^A-Za-z0-9_]/g, "").slice(0, 16);
const log = (...a) => console.log(new Date().toLocaleTimeString(), ...a);

// ---------- Mini serveur WebSocket (RFC 6455), sans dépendance ----------
const GUID = "258EAFA5-E914-47DA-95CA-C5AB0DC85B11";
let sock = null;                 // connexion Minecraft active
const waiting = new Map();       // requestId -> {resolve, timer}

function frame(opcode, payload) {
  const len = payload.length;
  let head;
  if (len < 126) head = Buffer.from([0x80 | opcode, len]);
  else if (len < 65536) { head = Buffer.alloc(4); head[0] = 0x80 | opcode; head[1] = 126; head.writeUInt16BE(len, 2); }
  else { head = Buffer.alloc(10); head[0] = 0x80 | opcode; head[1] = 127; head.writeBigUInt64BE(BigInt(len), 2); }
  return Buffer.concat([head, payload]);
}

function attach(socket) {
  let buf = Buffer.alloc(0), msg = [], msgOp = 0;
  socket.on("data", (chunk) => {
    buf = Buffer.concat([buf, chunk]);
    for (;;) {
      if (buf.length < 2) return;
      const fin = (buf[0] & 0x80) !== 0, op = buf[0] & 0x0f, masked = (buf[1] & 0x80) !== 0;
      let len = buf[1] & 0x7f, off = 2;
      if (len === 126) { if (buf.length < 4) return; len = buf.readUInt16BE(2); off = 4; }
      else if (len === 127) { if (buf.length < 10) return; len = Number(buf.readBigUInt64BE(2)); off = 10; }
      if (len > 5_000_000) return socket.destroy();
      const need = off + (masked ? 4 : 0) + len;
      if (buf.length < need) return;
      let payload = buf.subarray(off + (masked ? 4 : 0), need);
      if (masked) { const mask = buf.subarray(off, off + 4); payload = Buffer.from(payload.map((b, i) => b ^ mask[i % 4])); }
      buf = buf.subarray(need);
      if (op === 8) { socket.end(frame(8, Buffer.alloc(0))); return; }
      if (op === 9) { socket.write(frame(10, payload)); continue; }
      if (op === 10) continue;
      if (op === 1 || op === 2) { msg = [payload]; msgOp = op; } else if (op === 0) msg.push(payload);
      if (fin && msg.length) { const text = Buffer.concat(msg).toString("utf8"); msg = []; if (msgOp === 1) onMessage(text); }
    }
  });
}

function onMessage(text) {
  let m; try { m = JSON.parse(text); } catch (e) { return; }
  const id = m?.header?.requestId;
  const w = id && waiting.get(id);
  if (w) { clearTimeout(w.timer); waiting.delete(id); w.resolve(m.body || {}); }
}

// Envoie une commande Minecraft et attend la réponse (null si pas de réponse).
function command(commandLine) {
  return new Promise((resolve) => {
    if (!sock) return resolve(null);
    const id = crypto.randomUUID();
    const timer = setTimeout(() => { waiting.delete(id); resolve(null); }, 3000);
    waiting.set(id, { resolve, timer });
    const req = { header: { version: 1, requestId: id, messagePurpose: "commandRequest", messageType: "commandRequest" },
                  body: { origin: { type: "player" }, commandLine, version: 1 } };
    sock.write(frame(1, Buffer.from(JSON.stringify(req))));
  });
}

const server = http.createServer((req, res) => { res.end("ProxChat Helper : connecte Minecraft avec /connect localhost:" + PORT + "\n"); });
server.on("upgrade", (req, socket) => {
  const key = req.headers["sec-websocket-key"];
  if (!key) return socket.destroy();
  // Sécurité : un site web envoie toujours un en-tête Origin en http(s). On refuse donc toute connexion
  // venant d'une page web, et tout nom d'hôte autre que localhost (protection contre le DNS rebinding).
  const host = String(req.headers.host || "").toLowerCase().replace(/:\d+$/, "");
  const origin = String(req.headers.origin || "");
  if (/^https?:/i.test(origin) || !["localhost", "127.0.0.1", "[::1]"].includes(host)) {
    log("⛔ Connexion refusée (elle ne vient pas de Minecraft). Origin=" + (origin || "aucun") + " Host=" + host);
    return socket.destroy();
  }
  socket.write("HTTP/1.1 101 Switching Protocols\r\nUpgrade: websocket\r\nConnection: Upgrade\r\nSec-WebSocket-Accept: " +
    crypto.createHash("sha1").update(key + GUID).digest("base64") + "\r\n\r\n");
  if (sock) try { sock.destroy(); } catch (e) {}
  sock = socket; greeted = new Set();
  attach(socket);
  log("✅ Minecraft connecté. Le chat de proximité démarre.");
  socket.on("close", () => { if (sock === socket) { sock = null; log("⚠️ Minecraft déconnecté (relance /connect dans le jeu)."); } });
  socket.on("error", () => {});
});

// ---------- Lecture des joueurs ----------
function parseList(body) {
  if (!body) return [];
  let s = typeof body.players === "string" ? body.players : "";
  if (!s && typeof body.statusMessage === "string") {
    const lines = body.statusMessage.split("\n"); s = lines.length > 1 ? lines.slice(1).join(", ") : "";
  }
  return s.split(",").map((x) => x.trim()).filter(Boolean);
}

async function readPlayer(name) {
  const body = await command('querytarget "' + name.replace(/"/g, "") + '"');
  if (!body || body.statusCode) return null;
  try {
    const d = typeof body.details === "string" ? JSON.parse(body.details) : body.details;
    const e = Array.isArray(d) ? d[0] : d;
    if (!e?.position) return null;
    return { x: e.position.x, y: e.position.y, z: e.position.z, yaw: e.yRot || 0, dim: DIMS[e.dimension] || "minecraft:overworld" };
  } catch (err) { return null; }
}

let lastSig = "";
// 2 s seulement si deux joueurs sont à portée l'un de l'autre et que ça a bougé ; sinon 5 s.
function pickDelay(players) {
  let close = false;
  for (let i = 0; i < players.length && !close; i++) for (let j = i + 1; j < players.length; j++) {
    const a = players[i], b = players[j];
    if (a.dim === b.dim && Math.hypot(a.x - b.x, a.y - b.y, a.z - b.z) <= RANGE * 1.25 + 8) { close = true; break; }
  }
  const sig = players.map((p) => [p.name, Math.round(p.x * 2), Math.round(p.y * 2), Math.round(p.z * 2), Math.round(p.yaw / 5), p.dim].join(":")).join("|");
  const moved = sig !== lastSig; lastSig = sig;
  return close && moved ? FAST_MS : SOLO_MS;
}
let busy = false, link = "", lastErr = "", greeted = new Set();
const tellraw = (name, text) => command('tellraw "' + name.replace(/"/g, "") + '" {"rawtext":[{"text":' + JSON.stringify(text) + '}]}');

async function tick() {
  if (busy || !sock) return IDLE_MS;
  busy = true;
  let next = IDLE_MS;
  try {
    const names = parseList(await command("list"));
    if (!names.length) return IDLE_MS; // personne : on n'envoie rien au site
    const real = new Map(); // nom du site -> vrai pseudo
    const players = [];
    const infos = await Promise.all(names.map(readPlayer));
    names.forEach((n, i) => {
      const sn = siteName(n);
      if (sn.length < 3 || !infos[i]) return;
      real.set(sn, n);
      players.push({ name: sn, ...infos[i] });
    });
    next = pickDelay(players);
    const res = await fetch(SITE + "/api/positions", {
      method: "POST", headers: { "Content-Type": "application/json", "x-key": KEY },
      body: JSON.stringify({ range: RANGE, players }),
    });
    if (!res.ok) { const e = "Le site a répondu " + res.status; if (e !== lastErr) log("❌", e); lastErr = e; return; }
    lastErr = "";
    const data = await res.json();
    if (/^[a-f0-9]{16}$/.test(data.room || "")) link = SITE + "/?s=" + data.room;
    for (const v of data.verify || []) {
      const who = real.get(v?.name);
      if (who && /^\d{3,8}$/.test(String(v.code))) await tellraw(who, "§e[ProxChat] §fTon code : §a§l" + v.code);
    }
    greeted = new Set([...greeted].filter((n) => real.has(n)));
    if (link) for (const [sn, who] of real) {
      if (greeted.has(sn)) continue;
      greeted.add(sn);
      await tellraw(who, "§a[ProxChat] §fChat vocal de proximité : ouvre §b" + link + "§f et entre ton pseudo : §e" + sn);
    }
  } catch (e) {
    const m = "Erreur : " + e.message; if (m !== lastErr) log("❌", m); lastErr = m;
  } finally { busy = false; }
  return next;
}
async function loop() {
  let delay = IDLE_MS;
  try { delay = (await tick()) || IDLE_MS; } catch (e) {}
  setTimeout(loop, delay);
}

server.listen(PORT, "127.0.0.1", () => {
  log("ProxChat Helper prêt. Dans Minecraft (triches activées), tape :  /connect localhost:" + PORT);
  loop();
});
