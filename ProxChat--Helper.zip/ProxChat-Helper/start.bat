@echo off
cd /d "%~dp0"
node proxchat-helper.js
pause
